# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project
# Adapted from https://github.com/vllm-project/vllm/blob/a6221a144af772fd1a68fe7e627935dc53e81738/vllm/model_executor/layers/fused_moe/layer.py

import logging
from enum import Enum
from functools import cached_property
from typing import Dict, List, Optional, Tuple

import torch
from torch.nn.parameter import UninitializedParameter

from sglang.srt.batch_overlap.single_batch_overlap import DownGemmOverlapArgs
from sglang.srt.batch_overlap.two_batch_overlap import MaybeTboDeepEPDispatcher
from sglang.srt.distributed import (
    get_moe_ep_group,
    get_tp_group,
    tensor_model_parallel_all_reduce,
)
from sglang.srt.distributed.device_communicators.pynccl_allocator import (
    use_symmetric_memory,
)
from sglang.srt.environ import envs
from sglang.srt.eplb.expert_location import get_global_expert_location_metadata
from sglang.srt.layers.dp_attention import is_allocation_symmetric
from sglang.srt.layers.moe import (
    MoeRunnerConfig,
    get_deepep_mode,
    get_moe_a2a_backend,
    get_moe_runner_backend,
)
from sglang.srt.layers.moe.kt_ep_wrapper import (
    KTEPWrapperMethod,
    create_kt_config_from_server_args,
)
from sglang.srt.layers.moe.token_dispatcher import CombineInput, DispatchOutput
from sglang.srt.layers.moe.token_dispatcher.ascend_tp import (
    AscendTPDispatcher,
)
from sglang.srt.layers.moe.token_dispatcher.base import BaseDispatcher
from sglang.srt.layers.moe.token_dispatcher.flashinfer import FlashinferDispatcher
from sglang.srt.layers.moe.token_dispatcher.standard import (
    StandardDispatcher,
)
from sglang.srt.layers.moe.topk import (
    BypassedTopKOutput,
    StandardTopKOutput,
    TopKConfig,
    TopKOutput,
    TopKOutputChecker,
)
from sglang.srt.layers.moe.utils import (
    RoutingMethodType,
    has_per_rank_fused_shared_slots,
    uses_per_rank_fused_shared_slots,
)
from sglang.srt.layers.quantization.base_config import (
    FusedMoEMethodBase,
    QuantizationConfig,
)
from sglang.srt.layers.quantization.compressed_tensors.schemes import (
    CompressedTensorsMxInt4MoE,
)
from sglang.srt.layers.quantization.fp8 import Fp8MoEMethod
from sglang.srt.layers.quantization.fp8_utils import quantize_block_fp8_weight_to_mxfp4
from sglang.srt.layers.quantization.modelopt_quant import ModelOptNvFp4FusedMoEMethod
from sglang.srt.layers.quantization.unquant import UnquantizedFusedMoEMethod
from sglang.srt.model_executor.runner_backend_utils.tc_piecewise_cuda_graph import (
    get_tc_piecewise_forward_context,
    is_in_tc_piecewise_cuda_graph,
)
from sglang.srt.model_loader.weight_utils import narrow_padded_param_and_loaded_weight
from sglang.srt.runtime_context import (
    get_exec,
    get_global_dwdp_manager,
    get_parallel,
    get_server_args,
)
from sglang.srt.utils import (
    cpu_has_amx_support,
    get_bool_env_var,
    is_cpu,
    is_hip,
    is_npu,
    print_info_once,
    round_up,
)
from sglang.srt.utils.custom_op import register_custom_op

_is_hip = is_hip()
_is_cpu_amx_available = cpu_has_amx_support()
_is_cpu = is_cpu()
_is_npu = is_npu()
_use_aiter = get_bool_env_var("SGLANG_USE_AITER") and _is_hip

# Log the deferred-finalize config at most once per process (rank). Different MoE
# layers can resolve to different quant methods, so print_info_once (keyed on the
# full message) would otherwise fire once per distinct quant method.
_deferred_finalize_info_logged = False


def _copy_weight_view_before_h2d(loaded_weight: torch.Tensor) -> torch.Tensor:
    """Copy a CPU tensor view into independent contiguous storage."""
    if loaded_weight.device.type != "cpu":
        return loaded_weight
    tensor_bytes = loaded_weight.numel() * loaded_weight.element_size()
    needs_copy = not (
        loaded_weight.is_contiguous()
        and loaded_weight.storage_offset() == 0
        and loaded_weight.untyped_storage().nbytes() == tensor_bytes
    )
    if not needs_copy:
        return loaded_weight
    return loaded_weight.clone(memory_format=torch.contiguous_format)


def _maybe_copy_weight_view_before_h2d(
    loaded_weight: torch.Tensor,
) -> torch.Tensor:
    if not envs.SGLANG_MOE_COPY_WEIGHT_VIEWS_BEFORE_H2D.get():
        return loaded_weight
    return _copy_weight_view_before_h2d(loaded_weight)


def _get_deepep_comm_group(a2a_backend):
    group = get_tp_group().device_group

    if a2a_backend.is_mori():
        group = get_tp_group()

    elif _is_npu:
        group = get_moe_ep_group().device_group

    return group


def create_moe_dispatcher(moe_runner_config: MoeRunnerConfig) -> BaseDispatcher:
    a2a_backend = get_moe_a2a_backend()
    if a2a_backend.is_none() and is_npu():
        return AscendTPDispatcher(moe_runner_config)
    elif (
        a2a_backend.is_none()
        or a2a_backend.is_megamoe()
        or a2a_backend.is_ascend_fuseep()
    ):
        # ascend_fuseep bypasses the dispatcher abstraction (see
        # forward_fuseep in hardware_backend/npu/moe/fuseep.py); a
        # StandardDispatcher is created but never invoked.
        return StandardDispatcher(moe_runner_config)
    elif (
        a2a_backend.is_deepep()
        or a2a_backend.is_mooncake()
        or a2a_backend.is_mori()
        or a2a_backend.is_nixl()
        or a2a_backend.is_pplx()
    ):
        return MaybeTboDeepEPDispatcher(
            group=_get_deepep_comm_group(a2a_backend),
            router_topk=moe_runner_config.top_k,
            permute_fusion=True,
            num_experts=moe_runner_config.num_experts,
            num_local_experts=moe_runner_config.num_local_experts,
            hidden_size=moe_runner_config.hidden_size,
            params_dtype=moe_runner_config.params_dtype,
            deepep_mode=get_deepep_mode(),
            async_finish=True,
            return_recv_hook=True,
        )
    elif a2a_backend.is_flashinfer():
        return FlashinferDispatcher(
            group=get_tp_group().device_group,
            router_topk=moe_runner_config.top_k,
            num_experts=moe_runner_config.num_experts,
            num_local_experts=moe_runner_config.num_local_experts,
            hidden_size=moe_runner_config.hidden_size,
        )
    else:
        raise NotImplementedError(f"Unsupported a2a backend: {a2a_backend}")


class FusedMoeWeightScaleSupported(Enum):
    TENSOR = "tensor"
    CHANNEL = "channel"
    GROUP = "group"
    BLOCK = "block"


def _validate_hpc_ops_quant_method(quant_method) -> None:
    """--moe-runner-backend hpc_ops makes the standard dispatcher keep global
    expert ids for every MoE layer, so the resolved quant method must be the
    FP8 one the hpc_ops runner supports. Quant methods that never construct a
    MoeRunner (e.g. W4AFp8 calls its kernel directly from apply()) bypass the
    MoeRunner-level guard, so validate here at layer init.
    """
    if get_moe_runner_backend().is_hpc_ops() and not isinstance(
        quant_method, Fp8MoEMethod
    ):
        raise ValueError(
            "--moe-runner-backend hpc_ops only supports Fp8MoEMethod "
            "(FP8 blockwise or per-tensor MoE), but this layer selected "
            f"{type(quant_method).__name__}. Remove --moe-runner-backend "
            "hpc_ops for this model."
        )


class FusedMoE(torch.nn.Module):
    """FusedMoE layer for MoE models.

    This layer contains both MergedColumnParallel weights (gate_up_proj /
    w13) and RowParallelLinear weights (down_proj/ w2).

    Note: Mixtral uses w1, w2, and w3 for gate, up, and down_proj. We
    copy that naming convention here and handle any remapping in the
    load_weights function in each model implementation.

    Args:
        num_experts: Number of experts in the model
        top_k: Number of experts selected for each token
        hidden_size: Input hidden state size of the transformer
        intermediate_size: Intermediate size of the experts
        params_dtype: Data type for the parameters.
        reduce_results: Whether to apply all_reduce on the output of the layer
        quant_config: Quantization configuration.
        inplace: suggestion to compute inplace (modify input activation).
    """

    # True on shared-expert FusedMoE subclasses (e.g. Inkling's sink); lets
    # backend resolution distinguish them from routed experts.
    is_shared_fused_moe = False

    _skip_aiter_moe_shuffle: bool = False

    def __init__(
        self,
        num_experts: int,
        hidden_size: int,
        intermediate_size: int,
        layer_id: int,
        top_k: Optional[int] = None,
        num_fused_shared_experts: int = 0,
        params_dtype: Optional[torch.dtype] = None,
        reduce_results: bool = False,
        quant_config: Optional[QuantizationConfig] = None,
        prefix: str = "",
        activation: str = "silu",
        apply_router_weight_on_input: bool = False,
        use_presharded_weights: bool = False,
        inplace: bool = True,
        no_combine: bool = False,
        routed_scaling_factor: Optional[float] = None,
        gemm1_alpha: Optional[float] = None,
        gemm1_clamp_limit: Optional[float] = None,
        swiglu_limit: Optional[float] = None,
        use_weight_loader_fused: bool = False,
        with_bias=False,
        routing_method_type: Optional[RoutingMethodType] = None,
        is_gated: bool = True,
        gate_up_interleaved: bool = True,
    ):
        super().__init__()
        if params_dtype is None:
            params_dtype = torch.get_default_dtype()

        self.params_dtype = params_dtype
        self.layer_name = prefix
        self.layer_id = layer_id
        self.top_k = top_k
        self.hidden_size = hidden_size
        self.num_experts = num_experts
        self.with_bias = with_bias
        self.num_fused_shared_experts = num_fused_shared_experts

        self.enable_flashinfer_cutlass_moe = (
            get_moe_runner_backend().is_flashinfer_cutlass()
        )
        self.moe_ep_size = get_parallel().moe_ep_size
        self.moe_ep_rank = get_parallel().moe_ep_rank
        self.moe_tp_size = get_parallel().moe_tp_size
        self.moe_tp_rank = get_parallel().moe_tp_rank

        # For fused shared experts, DeepEP-class and MegaMOE backends use
        # per-rank physical shared slots, while other backends keep fused
        # shared experts as global shared slots. When fusion is disabled,
        # num_fused_shared_experts is 0 and no shared slots are added here.
        if has_per_rank_fused_shared_slots(num_fused_shared_experts):
            num_shared_slots = num_fused_shared_experts * self.moe_ep_size
        else:
            num_shared_slots = num_fused_shared_experts

        self._num_global_routed = num_experts - num_shared_slots
        if get_exec().moe.ep_join_mode == "scale":
            storage_ep_size = get_parallel().elastic_ep_initial_size
            assert storage_ep_size is not None
            self._expert_storage_rank = (
                get_parallel().ep_join_rank_offset + self.moe_ep_rank
            )
        else:
            storage_ep_size = self.moe_ep_size
            self._expert_storage_rank = self.moe_ep_rank
        assert self._num_global_routed % storage_ep_size == 0
        self._num_local_routed = self._num_global_routed // storage_ep_size
        self.num_local_experts = self._num_local_routed + num_fused_shared_experts
        self._has_fused_shared = num_fused_shared_experts > 0
        self._pending_fp8_shared_weights: dict[tuple[int, str], torch.Tensor] = {}
        self._pending_fp8_shared_scales: dict[tuple[int, str], torch.Tensor] = {}

        assert intermediate_size % self.moe_tp_size == 0
        self.intermediate_size_per_partition = intermediate_size // self.moe_tp_size
        self.reduce_results = reduce_results
        self.use_presharded_weights = use_presharded_weights

        self.use_triton_kernels = get_moe_runner_backend().is_triton_kernels()

        self.use_flashinfer_trtllm_moe = (
            get_moe_runner_backend().is_flashinfer_trtllm()
            or get_moe_runner_backend().is_flashinfer_trtllm_routed()
        )
        self.use_deep_gemm = get_moe_runner_backend().is_deep_gemm()

        # flashinfer_trtllm kernel requires intermediate_size to be a multiple of 128
        # Pad the intermediate_size_per_partition if necessary
        if (
            self.use_flashinfer_trtllm_moe
            and self.intermediate_size_per_partition % 128 != 0
        ):
            self.intermediate_size_per_partition = round_up(
                self.intermediate_size_per_partition, 128
            )

        self.quant_config = quant_config
        self.use_flashinfer_mxfp4_moe = get_moe_runner_backend().is_flashinfer_mxfp4()
        # TODO maybe we should remove this `if`, since `Mxfp4MoEMethod` does another round-up logic
        if (
            self.quant_config is not None
            and self.quant_config.get_name() == "mxfp4"
            and self.use_flashinfer_mxfp4_moe
        ):
            hidden_size = round_up(hidden_size, 256)
        self.hidden_size = hidden_size

        self.moe_runner_config = MoeRunnerConfig(
            num_experts=num_experts,
            num_local_experts=self.num_local_experts,
            hidden_size=hidden_size,
            intermediate_size_per_partition=self.intermediate_size_per_partition,
            layer_id=layer_id,
            top_k=top_k,
            num_fused_shared_experts=num_fused_shared_experts,
            params_dtype=params_dtype,
            activation=activation,
            apply_router_weight_on_input=apply_router_weight_on_input,
            inplace=inplace,
            no_combine=no_combine,
            routed_scaling_factor=routed_scaling_factor,
            gemm1_alpha=gemm1_alpha,
            gemm1_clamp_limit=gemm1_clamp_limit,
            swiglu_limit=swiglu_limit,
            is_gated=is_gated,
            routing_method_type=routing_method_type,
            gate_up_interleaved=gate_up_interleaved,
        )

        self.quant_method: Optional[FusedMoEMethodBase] = None
        server_args = get_server_args()
        kt_config = create_kt_config_from_server_args(server_args, layer_id)
        if kt_config is not None:
            if quant_config is not None:
                gpu_method = quant_config.get_quant_method(self, prefix)
            else:
                gpu_method = UnquantizedFusedMoEMethod(self.use_triton_kernels)
            self.quant_method = KTEPWrapperMethod(gpu_method, kt_config)
        else:
            if quant_config is not None:
                self.quant_method = quant_config.get_quant_method(self, prefix)
            if self.quant_method is None:
                self.quant_method = UnquantizedFusedMoEMethod(
                    self.use_triton_kernels,
                    self.use_flashinfer_trtllm_moe,
                    self.use_deep_gemm,
                )
        _validate_hpc_ops_quant_method(self.quant_method)
        self.supports_deferred_finalize = (
            envs.SGLANG_ENABLE_MOE_DEFERRED_FINALIZE.get()
            and get_moe_runner_backend().is_flashinfer_trtllm()
            and isinstance(self.quant_method, ModelOptNvFp4FusedMoEMethod)
        )
        global _deferred_finalize_info_logged
        if not _deferred_finalize_info_logged:
            _deferred_finalize_info_logged = True
            logging.getLogger(__name__).info(
                "FlashInfer TRTLLM MoE deferred finalize is "
                f"{'enabled' if self.supports_deferred_finalize else 'disabled'} "
                f"(moe_runner_backend={get_exec().moe.moe_runner_backend}, "
                f"quant_method={type(self.quant_method).__name__})."
            )

        self.quant_method.create_weights(
            layer=self,
            num_experts=self.num_local_experts,
            hidden_size=hidden_size,
            intermediate_size_per_partition=self.intermediate_size_per_partition,
            params_dtype=params_dtype,
            weight_loader=(
                self.weight_loader
                if not use_weight_loader_fused
                else self.weight_loader_fused
            ),
            with_bias=with_bias,
            moe_intermediate_size=intermediate_size,
        )

        self.quant_method.create_moe_runner(self, self.moe_runner_config)
        self.dispatcher = create_moe_dispatcher(self.moe_runner_config)
        self._use_ascend_fuseep = get_moe_a2a_backend().is_ascend_fuseep()

        if (
            get_moe_runner_backend().is_flashinfer_trtllm_routed()
            or get_moe_runner_backend().is_flashinfer_trtllm()
        ):
            if self.moe_runner_config.inplace:
                print_info_once(
                    "Setting inplace to False for FlashInfer TRTLLM MoE backend."
                )
            self.moe_runner_config.inplace = False

        self.should_fuse_routed_scaling_factor_in_topk = (
            (
                isinstance(self.quant_method, ModelOptNvFp4FusedMoEMethod)
                and not getattr(
                    self.quant_method, "_moe_runner_backend", get_moe_runner_backend()
                ).is_marlin()
            )
            or (
                isinstance(self.quant_method, Fp8MoEMethod)
                and (
                    get_moe_runner_backend().is_cutlass()
                    or get_moe_runner_backend().is_flashinfer_trtllm_routed()
                )
            )
            or (
                isinstance(self.quant_method, UnquantizedFusedMoEMethod)
                and get_moe_runner_backend().is_flashinfer_trtllm_routed()
            )
        )

        self.routing_method_type = routing_method_type

        # overlap args
        self.down_gemm_overlap_args: Optional[DownGemmOverlapArgs] = None
        self.meta_overlap_args: Optional[dict] = None

        self._dwdp_bound = False

        if self.quant_method is not None and hasattr(self.quant_method, "runner"):
            self.runner = self.quant_method.runner

    @property
    def num_global_routed_experts(self) -> int:
        return self._num_global_routed

    def bind_full_expert_weights(self, weights: Dict[str, torch.Tensor]) -> None:
        """Rebind this layer's expert weight tensors to externally provided
        full [num_experts, ...] tensors and collapse its EP view to a single
        rank that owns every routed expert (ep_size=1, no expert remapping).

        Callers are weight-replication schemes that materialize all expert
        weights locally after load time (e.g. DWDP's composite-VA prefetch).
        """
        self.moe_ep_size = 1
        self.moe_ep_rank = 0
        self._num_local_routed = self._num_global_routed
        self.num_local_experts = self.num_experts
        self.moe_runner_config.num_local_experts = self.num_local_experts

        self.dispatcher.moe_ep_size = 1
        self.dispatcher.moe_ep_rank = 0
        self.dispatcher.num_local_experts = self.num_local_experts
        self.dispatcher.num_local_routed_experts = self._num_local_routed
        self.dispatcher.local_expert_mapping = None
        self.dispatcher.expert_mask_gpu = None

        for name, tensor in weights.items():
            self.replace_expert_tensor(name, tensor)

        self._dwdp_bound = True

    def named_per_expert_tensors(
        self, num_local_experts: int
    ) -> List[Tuple[str, torch.Tensor]]:
        """Expert-sharded side tensors (dim0 == num_local_experts): quant
        scales, alphas, biases. Excludes the main w13/w2 expert weights."""
        found: Dict[str, torch.Tensor] = {}
        for name, param in self._parameters.items():
            if param is not None:
                found[name] = param.data
        for name, buf in self._buffers.items():
            if buf is not None and name not in found:
                found[name] = buf
        for name, value in vars(self).items():
            if isinstance(value, torch.Tensor) and name not in found:
                found[name] = value
        return [
            (name, tensor)
            for name, tensor in sorted(found.items())
            if name not in ("w13_weight", "w2_weight")
            and tensor.ndim > 0
            and tensor.shape[0] == num_local_experts
        ]

    def replace_expert_tensor(self, name: str, tensor: torch.Tensor) -> None:
        param = self._parameters.get(name)
        if param is not None:
            param.data = tensor
        else:
            setattr(self, name, tensor)

    @cached_property
    def use_padded_loading(self) -> bool:
        # This handles the case where the loaded weights are smaller than the padded expert_data
        # Use narrow_padded_param_and_loaded_weight for:
        # 1. CPU (always)
        # 2. GPU with flashinfer_trtllm padding (when intermediate_size is padded to 128)
        # 3. GPU with Aiter padding
        aiter_padded = (
            _use_aiter
            and hasattr(self, "w2_weight")
            and getattr(self.w2_weight, "weight_padded", False)
        )

        return _is_cpu or self.use_flashinfer_trtllm_moe or aiter_padded

    def _load_per_tensor_weight_scale(
        self,
        shard_id: str,
        param: torch.nn.Parameter,
        loaded_weight: torch.Tensor,
        expert_id: int,
    ):
        param_data = param.data
        # for per tensor weight quantization
        if shard_id in ("w1", "w3"):
            # We have to keep the weight scales of w1 and w3 because
            # we need to re-quantize w1/w3 weights after weight loading.
            idx = 0 if shard_id == "w1" else 1
            if self.moe_runner_config.is_gated:
                param_data[expert_id][idx] = loaded_weight
            else:
                param_data[expert_id] = loaded_weight
        # If we are in the row parallel case (down_proj)
        elif shard_id == "w2":
            param_data[expert_id] = loaded_weight

    def _load_model_weight_or_group_weight_scale(
        self,
        shard_dim: int,
        expert_data: torch.Tensor,
        shard_id: str,
        loaded_weight: torch.Tensor,
        tp_rank: int,
        is_bias: bool = False,
    ):
        # Load grouped weight scales for group quantization
        # or model weights
        if shard_id == "w2":
            self._load_w2(
                shard_id=shard_id,
                shard_dim=shard_dim,
                loaded_weight=loaded_weight,
                expert_data=expert_data,
                tp_rank=tp_rank,
                is_bias=is_bias,
            )
        elif shard_id in ("w1", "w3", "w13"):
            self._load_w13(
                shard_id=shard_id,
                shard_dim=shard_dim,
                loaded_weight=loaded_weight,
                expert_data=expert_data,
                tp_rank=tp_rank,
                is_bias=is_bias,
            )

    def _load_per_channel_weight_scale(
        self,
        expert_data: torch.Tensor,
        shard_dim: int,
        shard_id: str,
        loaded_weight: torch.Tensor,
        tp_rank: int,
    ):
        # for per channel weight quantization
        if shard_id == "w2":
            loaded_weight = _maybe_copy_weight_view_before_h2d(loaded_weight)
            expert_data.copy_(loaded_weight)
        elif shard_id in ("w1", "w3"):
            self._load_w13(
                shard_id=shard_id,
                shard_dim=shard_dim,
                loaded_weight=loaded_weight,
                expert_data=expert_data,
                tp_rank=tp_rank,
            )

    def _load_w13(
        self,
        expert_data: torch.Tensor,
        shard_dim: int,
        shard_id: str,
        loaded_weight: torch.Tensor,
        tp_rank: int,
        is_bias: bool = False,
    ):
        # Index the loaded weight for tp sharding.
        # gate_up_proj: "MergedColumnParallel", so tp sharding on output_dim
        assert shard_id in {"w1", "w3", "w13"}

        if is_bias:
            # if this weight is a bias, the last dimension must be the sharded dimension
            shard_dim = -1

        if shard_id in {"w1", "w3"} and self.moe_runner_config.is_gated:
            # non-fused version
            shard_size = expert_data.shape[shard_dim] // 2
        elif shard_id in {"w13"} or (
            shard_id in {"w1", "w3"} and not self.moe_runner_config.is_gated
        ):
            # fused version
            shard_size = expert_data.shape[shard_dim]
        else:
            raise NotImplementedError

        # Narrow parameter and load.
        # w1, gate_proj: Load into first logical weight of w13.
        # w3, up_proj: Load into second logical weight of w13.
        # trtllm cutlass kernel assumes differently
        switch_w13 = getattr(self.quant_method, "load_up_proj_weight_first", False)
        if (
            (switch_w13 and shard_id == "w1") or (not switch_w13 and shard_id == "w3")
        ) and self.moe_runner_config.is_gated:
            start = shard_size
        else:
            start = 0

        if self.use_padded_loading:
            if _is_cpu and is_bias:
                shard_dim = 1
            expert_data, loaded_weight = narrow_padded_param_and_loaded_weight(
                expert_data,
                loaded_weight,
                start,
                shard_size * tp_rank,
                shard_dim,
                shard_size,
                not self.use_presharded_weights,
            )
        else:
            if not self.use_presharded_weights:
                if not is_bias and self.use_triton_kernels:
                    # do not transpose for bias
                    loaded_weight = loaded_weight.transpose(-2, -1)
                # When the buffer is padded (e.g., MXFP4 SM100 rounds
                # intermediate up to 256), shard_size from the buffer may
                # exceed the checkpoint's per-TP slice.  Derive the actual
                # shard size from the loaded weight so we index correctly.
                loaded_shard_size = loaded_weight.shape[shard_dim] // self.moe_tp_size
                loaded_weight = loaded_weight.narrow(
                    shard_dim, loaded_shard_size * tp_rank, loaded_shard_size
                )

            expert_data = expert_data.narrow(shard_dim, start, shard_size)

        loaded_weight = _maybe_copy_weight_view_before_h2d(loaded_weight)
        # loaded_weight may be smaller than expert_data along shard_dim when
        # the buffer is padded.  Copy into the leading slice and leave the
        # trailing padding as zeros.  Rank-mismatched tensors (bias / scalar
        # scales) don't carry shard_dim; they keep the plain broadcast copy.
        if (
            loaded_weight.dim() == expert_data.dim()
            and shard_dim < expert_data.dim()
            and loaded_weight.shape[shard_dim] < expert_data.shape[shard_dim]
        ):
            expert_data.narrow(shard_dim, 0, loaded_weight.shape[shard_dim]).copy_(
                loaded_weight
            )
        else:
            expert_data.copy_(loaded_weight)

    def _load_w2(
        self,
        expert_data: torch.Tensor,
        shard_dim: int,
        shard_id: str,
        loaded_weight: torch.Tensor,
        tp_rank: int,
        is_bias: bool = False,
    ):
        """Load w2 weights for down projection.

        Args:
            expert_data: The expert data tensor to load into
            shard_dim: The dimension to shard along
            shard_id: The shard ID (must be "w2")
            loaded_weight: The weight tensor to load from
            tp_rank: The tensor parallel rank
        """
        if not isinstance(expert_data, torch.Tensor) or not isinstance(
            loaded_weight, torch.Tensor
        ):
            raise ValueError("expert_data and loaded_weight must be torch.Tensor")

        if (
            self.quant_config is not None
            and "modelopt" in self.quant_config.get_name()
            and (expert_data.dim() != 2 or loaded_weight.dim() != 2)
        ):
            raise ValueError(
                f"Expected 2D tensors, got expert_data shape {expert_data.shape} and loaded_weight shape {loaded_weight.shape}"
            )

        if shard_id != "w2":
            raise ValueError(f"shard_id must be 'w2', got {shard_id}")

        # Index the loaded weight for tp sharding.
        # down_proj: "RowParallel" so tp sharding on input_dim
        # Narrow parameter and load.
        if is_bias:
            # this expert_data is a bias, not weight,
            # for w2_weight_bias in TP, it does not need to be sharded
            shard_size = expert_data.shape[-1]
        else:
            # this parameter is a weight matrix
            # for w2 in TP, it shards the input_features, i.e., shard_dim=2
            shard_size = expert_data.shape[shard_dim]

        if self.use_padded_loading:
            if _is_cpu and is_bias:
                shard_dim = 1
            expert_data, loaded_weight = narrow_padded_param_and_loaded_weight(
                expert_data,
                loaded_weight,
                0,  # param_data_start
                shard_size * tp_rank,
                shard_dim,
                shard_size,
                not self.use_presharded_weights,
            )
        else:
            if not is_bias and not self.use_presharded_weights:
                if self.use_triton_kernels:
                    loaded_weight = loaded_weight.transpose(-2, -1)
                # Derive shard size from the loaded weight so padded buffers
                # do not cause out-of-bounds indexing into the checkpoint.
                loaded_shard_size = loaded_weight.shape[shard_dim] // self.moe_tp_size
                loaded_weight = loaded_weight.narrow(
                    shard_dim, loaded_shard_size * tp_rank, loaded_shard_size
                )

        # w2, down_proj: Load into only logical weight of w2.
        loaded_weight = _maybe_copy_weight_view_before_h2d(loaded_weight)
        # loaded_weight may be smaller than expert_data along shard_dim when
        # the buffer is padded.  Copy into the leading slice only.  See the
        # rank-mismatch note in _load_w13.
        if (
            loaded_weight.dim() == expert_data.dim()
            and shard_dim < expert_data.dim()
            and loaded_weight.shape[shard_dim] < expert_data.shape[shard_dim]
        ):
            expert_data.narrow(shard_dim, 0, loaded_weight.shape[shard_dim]).copy_(
                loaded_weight
            )
        else:
            expert_data.copy_(loaded_weight)

    def _maybe_load_fp8_shared_expert_as_fp4(
        self,
        param: torch.nn.Parameter,
        loaded_weight: torch.Tensor,
        weight_name: str,
        shard_id: str,
        expert_id: int,
        shard_dim: int,
        tp_rank: int,
    ) -> bool:
        if (
            not self._has_fused_shared
            or expert_id < self._num_local_routed
            or self.quant_config is None
            or not getattr(self.quant_config, "is_fp4_experts", False)
            or shard_id not in ("w1", "w2", "w3")
        ):
            return False

        is_weight = (
            "weight" in weight_name
            and "scale" not in weight_name
            and loaded_weight.dtype == torch.float8_e4m3fn
        )
        is_scale = "weight_scale_inv" in weight_name and loaded_weight.dtype in (
            torch.float8_e8m0fnu,
            torch.float32,
        )
        if not is_weight and not is_scale:
            return False

        weight_param = self.w2_weight if shard_id == "w2" else self.w13_weight
        scale_param = (
            self.w2_weight_scale_inv if shard_id == "w2" else self.w13_weight_scale_inv
        )
        if param is not weight_param and param is not scale_param:
            return False

        key = (expert_id, shard_id)
        if is_weight:
            fp8_weight = loaded_weight
            fp8_scale = self._pending_fp8_shared_scales.pop(key, None)
            if fp8_scale is None:
                self._pending_fp8_shared_weights[key] = loaded_weight
                return True
        else:
            fp8_weight = self._pending_fp8_shared_weights.pop(key, None)
            fp8_scale = loaded_weight
            if fp8_weight is None:
                self._pending_fp8_shared_scales[key] = loaded_weight
                return True

        logging.getLogger(__name__).warning_once(
            "Loading FP8 shared expert weights into FP4 fused MoE weights. "
            "The shared expert is quantized at load time and may differ "
            "slightly from a checkpoint that stores shared experts directly "
            "in FP4."
        )

        weight_block_size = getattr(self.quant_config, "weight_block_size", None)
        if weight_block_size is None:
            raise ValueError(
                "Loading FP8 shared expert weights into FP4 fused MoE weights "
                "requires block-FP8 weight_block_size."
            )
        fp4_weight, fp4_scale = quantize_block_fp8_weight_to_mxfp4(
            fp8_weight, fp8_scale, weight_block_size
        )

        weight_data = weight_param.data[expert_id]
        scale_data = scale_param.data[expert_id]
        self._load_model_weight_or_group_weight_scale(
            shard_dim=shard_dim,
            expert_data=weight_data,
            shard_id=shard_id,
            loaded_weight=fp4_weight,
            tp_rank=tp_rank,
        )
        self._load_model_weight_or_group_weight_scale(
            shard_dim=shard_dim,
            expert_data=scale_data,
            shard_id=shard_id,
            loaded_weight=fp4_scale,
            tp_rank=tp_rank,
        )
        return True

    def _load_single_value(
        self, param: torch.nn.Parameter, loaded_weight: torch.Tensor, expert_id: int
    ):
        param_data = param.data

        # Input scales can be loaded directly and should be equal.
        param_data[expert_id] = loaded_weight

    def _load_g_idx(
        self,
        shard_id: str,
        expert_data: torch.Tensor,
        shard_dim: int,
        loaded_weight: torch.Tensor,
        tp_rank: int,
    ):
        if shard_id == "w2":
            self._load_w2(
                shard_id=shard_id,
                shard_dim=shard_dim,
                loaded_weight=loaded_weight,
                expert_data=expert_data,
                tp_rank=tp_rank,
            )
        else:
            assert shard_id in ("w1", "w3")
            expert_data.copy_(loaded_weight)

    def _map_global_expert_id_to_local_expert_id(self, expert_id: int) -> int:
        start_idx = self._expert_storage_rank * self._num_local_routed
        end_idx = start_idx + self._num_local_routed
        if start_idx <= expert_id < end_idx:
            return expert_id - start_idx
        elif self._has_fused_shared and expert_id >= self._num_global_routed:
            return expert_id - self._num_global_routed + self._num_local_routed
        else:
            return -1

    def weight_loader(
        self,
        param: torch.nn.Parameter,
        loaded_weight: torch.Tensor,
        weight_name: str,
        shard_id: str,
        expert_id: Optional[int],
    ) -> None:
        # if expert_id is None, then
        # all the experts are loaded at the same time
        if (
            expert_id is None
            and self.quant_config is not None
            and self.quant_config.get_name() == "mxfp4"
            and self.quant_config.is_static_cfg()
        ):
            if "bias" in weight_name:
                dim1 = loaded_weight.shape[1]
                param.data[:, :dim1].copy_(loaded_weight)
            else:
                dim1 = loaded_weight.shape[1]
                dim2 = loaded_weight.shape[2]
                param.data[:, :dim1, :dim2].copy_(loaded_weight)
            return

        global_expert_location_metadata = get_global_expert_location_metadata()
        if global_expert_location_metadata is None:
            if not getattr(param, "_sglang_require_global_experts", False):
                expert_id = self._map_global_expert_id_to_local_expert_id(expert_id)
                if expert_id == -1:
                    return

            self._weight_loader_impl(
                param=param,
                loaded_weight=loaded_weight,
                weight_name=weight_name,
                shard_id=shard_id,
                expert_id=expert_id,
            )
            return

        require_global_experts = getattr(param, "_sglang_require_global_experts", False)
        shared_expert_id = (
            expert_id - global_expert_location_metadata.num_logical_experts
            if self._has_fused_shared and expert_id is not None
            else -1
        )
        if 0 <= shared_expert_id < self.num_fused_shared_experts:
            # Checkpoint shared experts start after logical routed experts, while
            # local fused MoE weights store them after physical routed experts.
            if require_global_experts and uses_per_rank_fused_shared_slots():
                physical_expert_ids = [
                    rank * self.num_local_experts
                    + self._num_local_routed
                    + shared_expert_id
                    for rank in range(self.moe_ep_size)
                ]
            else:
                physical_expert_ids = [self._num_global_routed + shared_expert_id]
        else:
            physical_expert_ids = (
                global_expert_location_metadata.logical_to_all_physical(
                    self.layer_id, expert_id, require_global_experts
                )
            )

        for physical_expert_id in physical_expert_ids:
            self._weight_loader_physical(
                param=param,
                loaded_weight=loaded_weight,
                weight_name=weight_name,
                shard_id=shard_id,
                expert_id=physical_expert_id,
            )

    def _weight_loader_physical(
        self,
        param: torch.nn.Parameter,
        loaded_weight: torch.Tensor,
        weight_name: str,
        shard_id: str,
        expert_id: int,
    ) -> None:
        # WARN: This makes the `expert_id` mean "local" and "global" in different cases
        if not getattr(param, "_sglang_require_global_experts", False):
            expert_id = self._map_global_expert_id_to_local_expert_id(expert_id)
            if expert_id < 0 or expert_id >= self.num_local_experts:
                return

        if isinstance(
            self.quant_method,
            KTEPWrapperMethod,
        ):
            if self.quant_method.num_gpu_experts != -1:
                if expert_id >= self.quant_method.num_gpu_experts:
                    return

        self._weight_loader_impl(
            param=param,
            loaded_weight=loaded_weight,
            weight_name=weight_name,
            shard_id=shard_id,
            expert_id=expert_id,
        )

    def _load_gguf_weight(
        self,
        param: torch.nn.Parameter,
        loaded_weight: torch.Tensor,
        shard_id: str,
        expert_id: int,
        tp_rank: int,
    ) -> bool:
        """Handle GGUF weight loading.

        Args:
            param: The parameter to load the weight into.
            loaded_weight: The weight tensor to load.
            shard_id: The shard ID (w1, w2, or w3).
            expert_id: The expert ID.
            tp_rank: The tensor parallel rank.

        Returns:
            True if the weight was handled as a GGUF weight, False otherwise.
        """
        is_gguf_weight = getattr(param, "is_gguf_weight", False)
        is_gguf_weight_type = getattr(param, "is_gguf_weight_type", False)

        if is_gguf_weight_type:
            # Store weight type for this expert
            param.weight_type = loaded_weight.item()
            return True

        if is_gguf_weight:
            output_dim = getattr(param, "output_dim", None)
            if self.moe_tp_size > 1:
                if shard_id in ["w1", "w3", "w2"] and output_dim == 0:
                    shard_size = loaded_weight.size(0) // self.moe_tp_size
                    start_idx = tp_rank * shard_size
                    loaded_weight = loaded_weight.narrow(
                        0, start_idx, shard_size
                    ).clone()

            # Store in data_container with expert/shard info
            if not hasattr(param, "expert_data_map"):
                param.expert_data_map = {}

            key = (expert_id, shard_id)
            param.expert_data_map[key] = loaded_weight
            param.data_container.append(loaded_weight)
            return True

        return False

    def _weight_loader_impl(
        self,
        param: torch.nn.Parameter,
        loaded_weight: torch.Tensor,
        weight_name: str,
        shard_id: str,
        expert_id: int,
    ) -> None:
        tp_rank = self.moe_tp_rank

        # Special case for GGUF weights
        if self._load_gguf_weight(param, loaded_weight, shard_id, expert_id, tp_rank):
            return

        # compressed-tensors checkpoints with packed weights are stored flipped
        # TODO (mgoin): check self.quant_method.quant_config.quant_format
        # against known CompressionFormat enum values that have this quality
        method = self.quant_method
        if hasattr(self, "scheme"):
            method = self.scheme
        if method.__class__.__name__ == "KTEPWrapperMethod":
            method = method.gpu_method

        # For flashinfer TRT-LLM BF16 path, process_weights_after_loading reshapes
        # expert weights into block layout. During weight update, we must restore
        # canonical load-time shapes before copying checkpoint tensors.
        if isinstance(method, UnquantizedFusedMoEMethod):
            method.maybe_restore_flashinfer_trtllm_bf16_weight_shape_for_load(
                layer=self,
                param=param,
                weight_name=weight_name,
            )
        elif isinstance(method, Fp8MoEMethod) and (
            get_moe_runner_backend().is_flashinfer_trtllm_routed()
            or get_moe_runner_backend().is_flashinfer_trtllm()
        ):
            # Drop the GPU mxfp8 shuffle-index cache on every reload for mxfp8 trtllm, trtllm_routed
            from sglang.srt.layers.moe.moe_runner.flashinfer_trtllm import (
                clear_mxfp8_shuffle_index_cache,
            )

            clear_mxfp8_shuffle_index_cache()

        loaded_weight = (
            loaded_weight.t().contiguous()
            if (
                method.__class__.__name__
                in [
                    "CompressedTensorsWNA16MarlinMoE",
                    "CompressedTensorsWNA16MoE",
                    "CompressedTensorsWNA16TritonMoE",
                ]
            )
            and "zero" not in weight_name
            else loaded_weight
        )

        if shard_id not in ("w1", "w2", "w3"):
            raise ValueError(f"shard_id must be ['w1','w2','w3'] but got {shard_id}.")

        # Flashinfer assumes w31 format for w13_weight. Same for the scales.
        if self.use_flashinfer_trtllm_moe and (
            isinstance(method, ModelOptNvFp4FusedMoEMethod)
            or isinstance(method, Fp8MoEMethod)
            or isinstance(method, UnquantizedFusedMoEMethod)
            or isinstance(method, CompressedTensorsMxInt4MoE)
        ):
            shard_id = {"w1": "w3", "w3": "w1", "w2": "w2"}[shard_id]

        WEIGHT_SCALE_SUPPORTED = [e.value for e in FusedMoeWeightScaleSupported]
        # Fetch the dim to shard the parameter/loaded weight
        # based on the shard id. This will be whatever
        # dimension intermediate_size is used.
        SHARD_ID_TO_SHARDED_DIM = {"w1": 0, "w2": 1, "w3": 0}

        expert_data = param.data[expert_id]

        # is_transposed: if the dim to shard the weight
        # should be flipped. Required by GPTQ, compressed-tensors
        # should be whatever dimension intermediate_size is
        is_transposed = getattr(param, "is_transposed", False)
        shard_dim = SHARD_ID_TO_SHARDED_DIM[shard_id]
        if self.use_triton_kernels:
            is_transposed = True
        if is_transposed:
            shard_dim = int(not shard_dim)

        if self._maybe_load_fp8_shared_expert_as_fp4(
            param=param,
            loaded_weight=loaded_weight,
            weight_name=weight_name,
            shard_id=shard_id,
            expert_id=expert_id,
            shard_dim=shard_dim,
            tp_rank=tp_rank,
        ):
            return

        # Case input scale: input_scale loading is only supported for fp8
        if "input_scale" in weight_name:
            # INT4-FP8 (INT4 MoE Weight, FP8 Compute): Adjust input_scale for e4m3fnuz (AMD)
            if _is_hip and get_bool_env_var("SGLANG_INT4_WEIGHT"):
                loaded_weight = loaded_weight * 2.0

            # this is needed for compressed-tensors only
            loaded_weight = loaded_weight.to(param.data.device)

            if (
                (
                    "compressed" in method.__class__.__name__.lower()
                    or "w4afp8" in self.quant_config.get_name()
                )
                and (param.data[expert_id] != 1).any()
                and ((param.data[expert_id] - loaded_weight).abs() > 1e-5).any()
            ):
                raise ValueError(
                    "input_scales of w1 and w3 of a layer "
                    f"must be equal. But got {param.data[expert_id]} "
                    f"vs. {loaded_weight}"
                )

            self._load_single_value(
                param=param, loaded_weight=loaded_weight, expert_id=expert_id
            )
            return

        # Case g_idx
        if "g_idx" in weight_name:
            self._load_g_idx(
                shard_dim=0,
                shard_id=shard_id,
                loaded_weight=loaded_weight,
                expert_data=expert_data,
                tp_rank=tp_rank,
            )
            return

        if "ModelOpt" in method.__class__.__name__:
            # Determine per-tensor weight scale patterns based on variant
            is_fp4_variant = isinstance(method, ModelOptNvFp4FusedMoEMethod)

            # FP4 uses "weight_scale_2" for per-tensor, FP8 uses "weight_scale" for per-tensor
            per_tensor_conditions = (
                "weight_scale_2" in weight_name
                if is_fp4_variant
                else "weight_scale" in weight_name
            ) or "input_scale" in weight_name

            if per_tensor_conditions:
                self._load_per_tensor_weight_scale(
                    shard_id=shard_id,
                    param=param,
                    loaded_weight=loaded_weight,
                    expert_id=expert_id,
                )
            elif "weight" in weight_name:
                self._load_model_weight_or_group_weight_scale(
                    shard_id=shard_id,
                    shard_dim=shard_dim,
                    loaded_weight=loaded_weight,
                    expert_data=expert_data,
                    tp_rank=tp_rank,
                )
            return

        # Case weight scales and zero_points
        if "scale" in weight_name or "zero" in weight_name or "offset" in weight_name:
            # load the weight scales and zp based on the quantization scheme
            # supported weight scales/zp can be found in
            # FusedMoeWeightScaleSupported
            # TODO @dsikka: once hardened, refactor to use vLLM Parameters
            # specific to each case
            quant_method = getattr(param, "quant_method", None)
            if quant_method == FusedMoeWeightScaleSupported.CHANNEL.value:
                # INT4-FP8 (INT4 MoE Weight, FP8 Compute): Adjust INT4 column-wise scaling number to e4m3fnuz (AMD)
                if _is_hip and get_bool_env_var("SGLANG_INT4_WEIGHT"):
                    loaded_weight = loaded_weight * 0.5

                self._load_per_channel_weight_scale(
                    shard_id=shard_id,
                    shard_dim=shard_dim,
                    loaded_weight=loaded_weight,
                    expert_data=expert_data,
                    tp_rank=tp_rank,
                )
            elif quant_method in [
                FusedMoeWeightScaleSupported.GROUP.value,
                FusedMoeWeightScaleSupported.BLOCK.value,
            ]:
                self._load_model_weight_or_group_weight_scale(
                    shard_id=shard_id,
                    shard_dim=shard_dim,
                    loaded_weight=loaded_weight,
                    expert_data=expert_data,
                    tp_rank=tp_rank,
                )
            elif quant_method == FusedMoeWeightScaleSupported.TENSOR.value:
                # INT4-FP8 (INT4 MoE Weight, FP8 Compute): Adjust FP8 per-tensor scaling number for e4m3fnuz (AMD)
                if _is_hip and get_bool_env_var("SGLANG_INT4_WEIGHT"):
                    loaded_weight = loaded_weight * 2.0

                self._load_per_tensor_weight_scale(
                    shard_id=shard_id,
                    param=param,
                    loaded_weight=loaded_weight,
                    expert_id=expert_id,
                )
            else:
                raise ValueError(
                    f"quant method must be one of {WEIGHT_SCALE_SUPPORTED}"
                )
            return

        # Case weight_shape
        if "weight_shape" in weight_name:
            # only required by compressed-tensors
            self._load_single_value(
                param=param, loaded_weight=loaded_weight, expert_id=expert_id
            )
            return

        # Case model weights
        if "weight" in weight_name:
            self._load_model_weight_or_group_weight_scale(
                shard_id=shard_id,
                shard_dim=shard_dim,
                loaded_weight=loaded_weight,
                expert_data=expert_data,
                tp_rank=tp_rank,
            )
            return

        if (
            "bias" in weight_name
            and self.quant_config.quant_description["quant_method"] == "modelslim"
        ):
            self._load_per_channel_weight_scale(
                shard_id=shard_id,
                shard_dim=shard_dim,
                loaded_weight=loaded_weight,
                expert_data=expert_data,
                tp_rank=tp_rank,
            )

    def weight_loader_fused(
        self,
        param: torch.nn.Parameter,
        loaded_weight: torch.Tensor,
        weight_name: str,
        shard_id: str,
    ) -> None:
        tp_rank = self.moe_tp_rank

        # Mirror _weight_loader_impl: the trtllm bf16 prep reshapes expert weights
        # into block layout; hot weight updates must restore canonical shapes first.
        method = self.quant_method
        if isinstance(method, KTEPWrapperMethod):
            method = method.gpu_method
        if isinstance(method, UnquantizedFusedMoEMethod):
            method.maybe_restore_flashinfer_trtllm_bf16_weight_shape_for_load(
                layer=self,
                param=param,
                weight_name=weight_name,
            )

        if (
            self.quant_config is not None
            and self.quant_config.get_name() == "mxfp4"
            and self.quant_config.is_static_cfg()
        ):
            if "bias" in weight_name:
                dim1 = loaded_weight.shape[1]
                param.data[:, :dim1].copy_(loaded_weight)
            elif "scale" in weight_name:
                param.data.copy_(loaded_weight)
            else:
                dim1 = loaded_weight.shape[1]
                dim2 = loaded_weight.shape[2]
                param.data[:, :dim1, :dim2].copy_(loaded_weight)
            return

        # compressed-tensors checkpoints with packed weights are stored flipped
        # TODO: check self.quant_method.quant_config.quant_format
        # against known CompressionFormat enum values that have this quality
        method = self.quant_method
        if hasattr(self, "scheme"):
            method = self.scheme
        if isinstance(method, Fp8MoEMethod) and (
            get_moe_runner_backend().is_flashinfer_trtllm_routed()
            or get_moe_runner_backend().is_flashinfer_trtllm()
        ):
            # Drop the GPU mxfp8 shuffle-index cache on every reload for mxfp8 trtllm, trtllm_routed
            from sglang.srt.layers.moe.moe_runner.flashinfer_trtllm import (
                clear_mxfp8_shuffle_index_cache,
            )

            clear_mxfp8_shuffle_index_cache()
        loaded_weight = (
            loaded_weight.t().contiguous()
            if (
                method.__class__.__name__
                in [
                    "CompressedTensorsWNA16MoE",
                    "CompressedTensorsWNA16TritonMoE",
                ]
            )
            and "zero" not in weight_name
            else loaded_weight
        )

        if shard_id not in ("w13", "w2"):
            raise ValueError(f"shard_id must be ['w13','w2'] but got {shard_id}.")

        # Fetch the dim to shard the parameter/loaded weight
        # based on the shard id. This will be whatever
        # dimension intermediate_size is used.
        SHARD_ID_TO_SHARDED_DIM = {"w13": 1, "w2": 2}
        SHARD_ID_TO_SHARDED_DIM_TRANSPOSE = {"w13": 2, "w2": 1}

        expert_data = param.data
        is_bias = expert_data.dim() == 2

        # is_transposed: if the dim to shard the weight
        # should be flipped. Required by GPTQ, compressed-tensors
        # should be whatever dimension intermediate_size is
        is_transposed = getattr(param, "is_transposed", False)

        if self.use_triton_kernels:
            is_transposed = True
        shard_dim = (
            SHARD_ID_TO_SHARDED_DIM[shard_id]
            if not is_transposed
            else SHARD_ID_TO_SHARDED_DIM_TRANSPOSE[shard_id]
        )

        # Case model weights
        if "weight" in weight_name:
            self._load_model_weight_or_group_weight_scale(
                shard_id=shard_id,
                shard_dim=shard_dim,
                loaded_weight=loaded_weight,
                expert_data=expert_data,
                tp_rank=tp_rank,
                is_bias=is_bias,
            )
            return
        else:
            logging.warning(
                f"Unsupported weight_name {weight_name} for FusedMoE weight_loader_fused. Nothing is loaded."
            )

    def forward(
        self,
        hidden_states: torch.Tensor,
        topk_output: TopKOutput,
        pre_quant_input: Optional[Tuple[torch.Tensor, torch.Tensor]] = None,
    ):
        if self._use_ascend_fuseep:
            from sglang.srt.hardware_backend.npu.moe.fuseep import forward_fuseep

            return forward_fuseep(self, hidden_states, topk_output)
        if is_in_tc_piecewise_cuda_graph():
            if TopKOutputChecker.format_is_standard(topk_output):
                return moe_forward_piecewise_cuda_graph_impl(
                    hidden_states,
                    topk_output.topk_weights,
                    topk_output.topk_ids,
                    topk_output.router_logits,
                    self.layer_id,
                )
            elif TopKOutputChecker.format_is_bypassed(topk_output):
                return fused_moe_bypassed_piecewise_cuda_graph_impl(
                    hidden_states,
                    topk_output.router_logits,
                    topk_output.topk_config.top_k,
                    topk_output.topk_config.topk_group,
                    topk_output.topk_config.num_expert_group,
                    topk_output.topk_config.correction_bias,
                    topk_output.topk_config.renormalize,
                    self.layer_id,
                    topk_output.topk_config.allow_routed_experts_capture,
                )
            else:
                # Make sure there is torch lib op registration for the whole moe layer
                return self.forward_impl(
                    hidden_states, topk_output, pre_quant_input=pre_quant_input
                )
        else:
            return self.forward_impl(
                hidden_states, topk_output, pre_quant_input=pre_quant_input
            )

    def forward_impl(
        self,
        hidden_states: torch.Tensor,
        topk_output: TopKOutput,
        pre_quant_input: Optional[Tuple[torch.Tensor, torch.Tensor]] = None,
    ):
        origin_hidden_states_dim = hidden_states.shape[-1]
        assert self.quant_method is not None

        if self._dwdp_bound:
            dwdp_mgr = get_global_dwdp_manager()
            dwdp_mgr.wait_prefetch(self.layer_id)

        dispatch_output = self.dispatcher.dispatch(
            hidden_states=hidden_states, topk_output=topk_output
        )
        if (
            pre_quant_input is not None
            and dispatch_output.format.is_standard()
            and dispatch_output.hidden_states_scale is None
        ):
            # SGLANG_OPT_MOE_QUANT_ONCE: the standard dispatch was a pure
            # passthrough, so the caller's pre-quantized (q, scale) pair still
            # matches dispatch_output.hidden_states; attach it for the triton
            # fused runner to skip its own activation quant.
            dispatch_output = dispatch_output._replace(
                hidden_states_pre_quant=pre_quant_input
            )

        combine_input = self.run_moe_core(
            dispatch_output=dispatch_output,
        )

        if self._dwdp_bound:
            dwdp_mgr.record_compute_and_prefetch_next(self.layer_id)

        with use_symmetric_memory(
            get_tp_group(), disabled=not is_allocation_symmetric()
        ):
            final_hidden_states = self.dispatcher.combine(combine_input=combine_input)

            # TODO: should we add some conditions here?
            final_hidden_states = final_hidden_states[
                ..., :origin_hidden_states_dim
            ].contiguous()

        if self.reduce_results and (self.moe_tp_size > 1 or self.moe_ep_size > 1):
            final_hidden_states = tensor_model_parallel_all_reduce(final_hidden_states)

        return final_hidden_states

    def forward_deferred_finalize(
        self, hidden_states: torch.Tensor, topk_output: TopKOutput
    ):
        assert self.quant_method is not None
        from sglang.srt.layers.moe.moe_runner.flashinfer_trtllm import (
            flashinfer_trtllm_deferred_finalize_context,
        )

        dispatch_output = self.dispatcher.dispatch(
            hidden_states=hidden_states, topk_output=topk_output
        )

        with flashinfer_trtllm_deferred_finalize_context():
            combine_input = self.run_moe_core(dispatch_output=dispatch_output)

        return self.dispatcher.combine(combine_input=combine_input)

    def run_moe_core(self, dispatch_output: DispatchOutput) -> CombineInput:
        # TODO: consider using symmetric memory
        return self.quant_method.apply(
            layer=self,
            dispatch_output=dispatch_output,
        )

    @classmethod
    def make_expert_params_mapping(
        cls,
        ckpt_gate_proj_name: str,
        ckpt_down_proj_name: str,
        ckpt_up_proj_name: str,
        num_experts: int,
    ) -> List[Tuple[str, str, int, str]]:
        return [
            # (param_name, weight_name, expert_id, shard_id)
            (
                (
                    "experts.w13_"
                    if weight_name in [ckpt_gate_proj_name, ckpt_up_proj_name]
                    else "experts.w2_"
                ),
                f"experts.{expert_id}.{weight_name}.",
                expert_id,
                shard_id,
            )
            for expert_id in range(num_experts)
            for shard_id, weight_name in [
                ("w1", ckpt_gate_proj_name),
                ("w2", ckpt_down_proj_name),
                ("w3", ckpt_up_proj_name),
            ]
        ]

    @classmethod
    def make_expert_params_mapping_fused(
        cls,
        ckpt_gate_up_proj_name: str,
        ckpt_down_proj_name: str,
        ckpt_gate_up_proj_bias_name: str,
        ckpt_down_proj_bias_name: str,
    ):
        return [
            ("experts.w13_weight", f"experts.{ckpt_gate_up_proj_name}", "w13"),
            (
                "experts.w13_weight_bias",
                f"experts.{ckpt_gate_up_proj_bias_name}",
                "w13",
            ),
            ("experts.w2_weight", f"experts.{ckpt_down_proj_name}", "w2"),
            ("experts.w2_weight_bias", f"experts.{ckpt_down_proj_bias_name}", "w2"),
        ]

    @classmethod
    def make_expert_params_mapping_fused_mxfp4(
        cls,
        ckpt_gate_up_proj_name: str,
        ckpt_down_proj_name: str,
        ckpt_gate_up_proj_bias_name: str,
        ckpt_down_proj_bias_name: str,
        ckpt_gate_up_proj_scale_name: str,
        ckpt_down_proj_scale_name: str,
    ):
        return [
            ("experts.w13_weight", f"experts.{ckpt_gate_up_proj_name}", "w13"),
            (
                "experts.w13_weight_bias",
                f"experts.{ckpt_gate_up_proj_bias_name}",
                "w13",
            ),
            ("experts.w2_weight", f"experts.{ckpt_down_proj_name}", "w2"),
            ("experts.w2_weight_bias", f"experts.{ckpt_down_proj_bias_name}", "w2"),
            (
                "experts.w13_weight_scale",
                f"experts.{ckpt_gate_up_proj_scale_name}",
                "w13",
            ),
            ("experts.w2_weight_scale", f"experts.{ckpt_down_proj_scale_name}", "w2"),
        ]

    @classmethod
    def make_expert_input_scale_params_mapping(
        cls,
        num_experts: int,
    ) -> List[Tuple[str, str, int, str]]:
        # (param_name, weight_name, expert_id, shard_id)
        return [
            (
                "experts.w13_" if shard_id in ["w1", "w3"] else "experts.w2_",
                f"experts.{expert_id}.{shard_id}.",
                expert_id,
                shard_id,
            )
            for expert_id in range(num_experts)
            for shard_id in ["w1", "w2", "w3"]
        ]

    def set_overlap_args(
        self, down_gemm_overlap_args: DownGemmOverlapArgs, meta_overlap_args: dict
    ):
        if hasattr(self, "runner"):
            self.runner.set_overlap_args(down_gemm_overlap_args, meta_overlap_args)
        else:
            # TODO: remove this branch after MoE refactor
            self.down_gemm_overlap_args = down_gemm_overlap_args
            self.meta_overlap_args = meta_overlap_args

    def clear_overlap_args(self) -> None:
        if hasattr(self, "runner"):
            self.runner.clear_overlap_args()
        else:
            # TODO: remove this branch after MoE refactor
            self.down_gemm_overlap_args = None
            self.meta_overlap_args = None

    def materialize_gguf_weights(self) -> None:
        """Process weights after loading, especially for GGUF quantization.

        This materializes GGUF UninitializedParameters from their data_containers.
        """

        for name, param in list(self.named_parameters()):
            is_gguf_weight = getattr(param, "is_gguf_weight", False)

            if is_gguf_weight and isinstance(param, UninitializedParameter):
                data_container = getattr(param, "data_container", [])
                expert_data_map = getattr(param, "expert_data_map", {})
                tensor_shape = getattr(param, "tensor_shape", None)

                if data_container and tensor_shape:
                    # Determine the structure from expert_data_map
                    num_experts = tensor_shape[0]

                    # Collect weights by expert
                    expert_weights = {}
                    for (expert_id, shard_id), weight in expert_data_map.items():
                        if expert_id not in expert_weights:
                            expert_weights[expert_id] = {}
                        expert_weights[expert_id][shard_id] = weight

                    # Build the full tensor
                    if "w13" in name:
                        # w13 is gate+up fused
                        weight_list = []
                        for e in range(num_experts):
                            if e in expert_weights:
                                w1 = expert_weights[e].get("w1")
                                w3 = expert_weights[e].get("w3")

                                if w1 is not None and w3 is not None:
                                    fused = torch.cat([w1, w3], dim=0)
                                    weight_list.append(fused)

                        if weight_list:
                            stacked = torch.stack(weight_list, dim=0)
                            param.materialize(stacked.shape, dtype=stacked.dtype)
                            param.data.copy_(stacked)
                    elif "w2" in name:
                        # w2 is down projection
                        weight_list = []
                        for e in range(num_experts):
                            if e in expert_weights and "w2" in expert_weights[e]:
                                w2_weight = expert_weights[e]["w2"]
                                weight_list.append(w2_weight)

                        if weight_list:
                            stacked = torch.stack(weight_list, dim=0)
                            param.materialize(stacked.shape, dtype=stacked.dtype)
                            param.data.copy_(stacked)


@register_custom_op(out_shape="hidden_states")
def moe_forward_piecewise_cuda_graph_impl(
    hidden_states: torch.Tensor,
    topk_weights: torch.Tensor,
    topk_ids: torch.Tensor,
    router_logits: torch.Tensor,
    layer_id: int,
) -> torch.Tensor:
    # only standard topk output is supported for piecewise cuda graph
    topk_output = StandardTopKOutput(
        topk_weights=topk_weights, topk_ids=topk_ids, router_logits=router_logits
    )
    forward_context = get_tc_piecewise_forward_context()
    moe_layer = forward_context.moe_layers[layer_id]
    return moe_layer.forward_impl(hidden_states, topk_output)


@register_custom_op(out_shape="hidden_states")
def fused_moe_bypassed_piecewise_cuda_graph_impl(
    hidden_states: torch.Tensor,
    router_logits: torch.Tensor,
    top_k: int,
    topk_group: Optional[int],
    num_expert_group: Optional[int],
    correction_bias: Optional[torch.Tensor],
    renormalize: bool,
    layer_id: int,
    allow_routed_experts_capture: bool,
) -> torch.Tensor:
    topk_output = BypassedTopKOutput(
        hidden_states=hidden_states,
        router_logits=router_logits,
        topk_config=TopKConfig(
            top_k=top_k,
            topk_group=topk_group,
            num_expert_group=num_expert_group,
            correction_bias=correction_bias,
            renormalize=renormalize,
            allow_routed_experts_capture=allow_routed_experts_capture,
        ),
    )
    forward_context = get_tc_piecewise_forward_context()
    moe_layer = forward_context.moe_layers[layer_id]
    return moe_layer.forward_impl(hidden_states, topk_output)
